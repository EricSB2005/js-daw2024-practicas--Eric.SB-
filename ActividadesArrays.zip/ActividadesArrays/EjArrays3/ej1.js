// Función para generar una combinación de 6 números únicos del 1 al 49
function crearCombinacionLoteria() {
    const numerosUnicos = new Set();
    // Genera números aleatorios hasta obtener 6 únicos
    while (numerosUnicos.size < 6) {
        const numeroAleatorio = Math.floor(Math.random() * 49) + 1;
        numerosUnicos.add(numeroAleatorio);
    }
    return Array.from(numerosUnicos);
}

// Función para generar múltiples combinaciones de lotería
function crearVariasCombinaciones(cantidadCombinaciones) {
    const todasLasCombinaciones = [];
    // Genera la cantidad especificada de combinaciones
    for (let i = 0; i < cantidadCombinaciones; i++) {
        todasLasCombinaciones.push(crearCombinacionLoteria());
    }
    return todasLasCombinaciones;
}


/*EJERCICIO 2*/

// Función para calcular la frecuencia de números aleatorios del 1 al 10
function contarFrecuenciasAleatorias(cantidadGeneraciones, rangoMinimo, rangoMaximo) {
    const conteoFrecuencias = new Array(rangoMaximo - rangoMinimo + 1).fill(0);

    // Genera números aleatorios y cuenta sus frecuencias
    for (let i = 0; i < cantidadGeneraciones; i++) {
        const numeroAleatorio = Math.floor(Math.random() * (rangoMaximo - rangoMinimo + 1)) + rangoMinimo;
        conteoFrecuencias[numeroAleatorio - rangoMinimo]++;
    }

    return conteoFrecuencias;
}

// Generación de 50 combinaciones de lotería
const combinacionesLoteria = crearVariasCombinaciones(50);
console.log("Combinaciones de Lotería:");
console.log(combinacionesLoteria);

// Cálculo de frecuencias de números aleatorios del 1 al 10
const cantidadGeneraciones = 10000;
const rangoMinimo = 1;
const rangoMaximo = 10;
const frecuenciasNumeros = contarFrecuenciasAleatorias(cantidadGeneraciones, rangoMinimo, rangoMaximo);

// Mostrar las frecuencias de los números
console.log("Frecuencias:");
for (let i = 0; i < frecuenciasNumeros.length; i++) {
    console.log(`Número ${i + rangoMinimo}: ${frecuenciasNumeros[i]}`);
}