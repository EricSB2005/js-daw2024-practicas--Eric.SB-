//Creo mi array y otras variables
const palabras = ["ana", "radar", "javascript", "reconocer", "oro", "palindromo", "salas"];
let palindomos=[];


//Averiguo cuales son palindromos y cuales no

palabras.forEach(palabra => {
    if(palabra=palabra.split('').reverse().join('')){
        palindomos.push(palabra);
    }
});

//Recorremos las arrays 

palindomos.forEach(palindormo => {
    console.log(palindormo);
});
