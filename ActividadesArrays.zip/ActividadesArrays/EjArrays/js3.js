//Creo mis arrays 'nombres' y 'edad4es'
let nombres=['Ana', 'Mario', 'Luis', 'Carlos', 'Alicia'];
let edades=[17,22,45,8,31];

//Las recorro
nombres.forEach(nombre => {
    console.log(nombre);
});

edades.forEach(edad => {
    console.log(edad);
});


//Creo mi array 'mayoresDeEdad'
let mayoresDeEdad=[];
for(let i in nombres){
    if( (edades[i]) >= 18){
        mayoresDeEdad[i]=nombres[i];
    }
}

//recorro 'mayoresDeEdad'

mayoresDeEdad.forEach(mayorEdad => {
    console.log(mayorEdad);
});