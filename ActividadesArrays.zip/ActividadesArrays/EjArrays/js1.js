//Creo mi array de colores
const colores =['rojo','verde','azul'];

//muestro mi array 
console.log('Estos son los colores', colores);

//cambio el valor de mi array en la posición 1
colores[1]= 'amarillo';

//vuelvo a mostrar mi array
console.log('Estos son los colores cambiados',colores);