//Creo mi array de países
let paises =['España','Francia','Alemania','Italia'];

//la recorro
for(let pais of paises){
    console.log(pais);
}

//elimino el primer elemento
paises.shift();


//lo vuelvo a recorrer
paises.forEach(pais => {
    console.log(pais);
});