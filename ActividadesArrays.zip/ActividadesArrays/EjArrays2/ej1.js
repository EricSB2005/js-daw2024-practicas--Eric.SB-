let array = new Array (12);

for(let i=0;i<10;i++){
    array[i]=5;
}

console.log(array);