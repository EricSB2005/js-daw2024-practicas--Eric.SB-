const nombres = ["Ana", "Pedro", "Juan", "Sofía", "Carlos"];

nombres.sort();

console.log(nombres);

nombres.reverse();

console.log(nombres);
