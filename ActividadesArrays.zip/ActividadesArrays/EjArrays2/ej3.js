let colores = ["rojo", "verde", "azul", "amarillo", "naranja", "violeta"];
let Ncolores = [];

for (let i = 1; i <= 4; i++) {
  Ncolores[i - 1] = colores[i];
}

console.log(colores);
console.log(Ncolores);

colores.splice(3, 2);

console.log(colores);

colores.splice(3, 0 , 'negro' , 'blanco')

console.log(colores);