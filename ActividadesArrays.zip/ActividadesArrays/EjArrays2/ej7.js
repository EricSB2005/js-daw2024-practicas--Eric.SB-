
const letras = ['a', 'b', 'c', 'd'];

const contieneC = letras.includes('c');
const contieneZ = letras.includes('z');


console.log("Contiene 'c':", contieneC); // true
console.log("Contiene 'z':", contieneZ); // false