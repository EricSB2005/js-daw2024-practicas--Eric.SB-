
function buscarProducto(productos, nombreProducto) {
 
    const productoEncontrado = productos.find(producto => producto.nombre === nombreProducto);
    

    return productoEncontrado || null;
}


let productos = [ 
    { nombre: "Laptop", categoria: "Electrónica", precio: 1500 }, 
    { nombre: "Silla", categoria: "Muebles", precio: 100 },
    { nombre: "Cargador", categoria: "Electrónica", precio: 50 }
];

console.log(buscarProducto(productos, "Laptop")); 
console.log(buscarProducto(productos, "Mesa")); 