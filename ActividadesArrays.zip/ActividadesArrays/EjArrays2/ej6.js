
const numeros = [4, 21, 33, 12, 9, 54];


const numerosPares = numeros.filter(num => num % 2 === 0);


console.log(numerosPares); 