
const edades = [25, 30, 18, 40, 25, 30];


const primeraPos30 = edades.indexOf(30);

const ultimaPos25 = edades.lastIndexOf(25);

console.log("Primera aparición de 30:", primeraPos30); 
console.log("Última aparición de 25:", ultimaPos25); 