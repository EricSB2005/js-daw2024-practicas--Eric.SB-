<?php
require_once '../includes/connection.inc.php';

// Verificar si el usuario está autenticado
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$currentUserId = $_SESSION['user_id'];

// Verificar si se pasó un ID de usuario válido para seguir/dejar de seguir
if (!isset($_POST['follow_id']) || !is_numeric($_POST['follow_id'])) {
    die('ID de usuario no válido.');
}

$followId = (int)$_POST['follow_id'];

// Prevenir que el usuario se siga a sí mismo
if ($currentUserId === $followId) {
    die('No puedes seguirte a ti mismo.');
}

// Verificar si ya sigue al usuario
$stmt = $pdo->prepare("SELECT * FROM follows WHERE user_id = ? AND user_followed = ?");
$stmt->execute([$currentUserId, $followId]);
$isFollowing = $stmt->fetch();

if ($isFollowing) {
    // Si ya lo sigue, eliminar la relación
    $stmt = $pdo->prepare("DELETE FROM follows WHERE user_id = ? AND user_followed = ?");
    $stmt->execute([$currentUserId, $followId]);
    $message = "Has dejado de seguir al usuario.";
} else {
    // Si no lo sigue, agregar la relación
    $stmt = $pdo->prepare("INSERT INTO follows (user_id, user_followed) VALUES (?, ?)");
    $stmt->execute([$currentUserId, $followId]);
    $message = "Ahora sigues al usuario.";
}

// Redirigir a la página anterior con un mensaje opcional
header('Location: ' . $_SERVER['HTTP_REFERER']);
exit;
