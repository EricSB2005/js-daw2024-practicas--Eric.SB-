<?php
session_start();
require_once '../includes/connection.inc.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$userId = $_SESSION['user_id'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['confirm']) && $_POST['confirm'] === 'on') {
        // Eliminar comentarios del usuario
        $stmt = $pdo->prepare("DELETE FROM comments WHERE user_id = ?");
        $stmt->execute([$userId]);

        // Eliminar publicaciones del usuario y sus comentarios asociados
        $stmt = $pdo->prepare("SELECT id FROM entries WHERE user_id = ?");
        $stmt->execute([$userId]);
        $entries = $stmt->fetchAll();

        foreach ($entries as $entry) {
            $stmt = $pdo->prepare("DELETE FROM comments WHERE entry_id = ?");
            $stmt->execute([$entry['id']]);
        }

        $stmt = $pdo->prepare("DELETE FROM entries WHERE user_id = ?");
        $stmt->execute([$userId]);

        // Eliminar relaciones de seguimiento
        $stmt = $pdo->prepare("DELETE FROM follows WHERE user_id = ? OR user_followed = ?");
        $stmt->execute([$userId, $userId]);

        // Eliminar al usuario
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$userId]);

        // Cerrar la sesión
        session_destroy();
        header('Location: ../index.php');
        exit;
    } else {
        $error = 'Debes marcar la casilla para confirmar.';
    }
}
?>

<?php include '../includes/header.inc.php'; ?>

<h1>Eliminar Cuenta</h1>

<?php if ($error): ?>
    <p style="color: red;"><?= $error ?></p>
<?php endif; ?>

<form method="post">
    <p>¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.</p>
    <label>
        <input type="checkbox" name="confirm"> Confirmo que deseo eliminar mi cuenta.
    </label>
    <br>
    <button type="submit">Eliminar Cuenta</button>
</form>

<?php include '../includes/footer.inc.php'; ?>
