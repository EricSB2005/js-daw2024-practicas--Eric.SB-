<?php
session_start();
require_once '../includes/connection.inc.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['user'];
    $password = $_POST['password'];

    // Consultar usuario en la base de datos
    $stmt = $pdo->prepare("SELECT id, password FROM users WHERE user = ?");
    $stmt->execute([$user]);
    $userData = $stmt->fetch();

    // Verificar credenciales
    if ($userData && password_verify($password, $userData['password'])) {
        $_SESSION['user_id'] = $userData['id'];
        header('Location: ../index.php');
        exit;
    } else {
        $error = 'Usuario o contraseña incorrectos.';
    }
}
?>

<?php include '../includes/header.inc.php'; ?>

<h1>Iniciar Sesión</h1>

<?php if ($error): ?>
    <p style="color: red;"><?= $error ?></p>
<?php endif; ?>

<form method="post">
    <input type="text" name="user" placeholder="Usuario" required>
    <input type="password" name="password" placeholder="Contraseña" required>
    <button type="submit">Entrar</button>
</form>

<?php include '../includes/footer.inc.php'; ?>
