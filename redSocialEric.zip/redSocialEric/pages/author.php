<?php include '../includes/header.inc.php'; ?>

<h1>Autor</h1>

<div style="text-align: center;">
    <img src="../img/miFoto.jpg" alt="Foto del autor" style="width: 200px; height: 200px; border-radius: 80%; border: 2px solid #ccc;">
    <p><strong>Eric Saavedra</strong></p>
   
</div>

<?php include '../includes/footer.inc.php'; ?>
