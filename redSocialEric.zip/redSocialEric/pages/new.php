<?php
require_once '../includes/connection.inc.php';
include '../includes/header.inc.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $text = $_POST['text'];
    $userId = $_SESSION['user_id'];

    if (empty($text)) {
        $error = 'El texto de la publicación no puede estar vacío.';
    } else {
        $stmt = $pdo->prepare("INSERT INTO entries (user_id, text) VALUES (?, ?)");
        $stmt->execute([$userId, $text]);
        header('Location: ../index.php');
        exit;
    }
}
?>

<h1>Nueva Publicación</h1>

<?php if ($error): ?>
    <p style="color: red;"><?= $error ?></p>
<?php endif; ?>

<form method="post">
    <textarea name="text" placeholder="Escribe tu publicación aquí..." required></textarea>
    <button type="submit">Publicar</button>
</form>

<?php include '../includes/footer.inc.php'; ?>
