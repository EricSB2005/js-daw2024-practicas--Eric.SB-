<?php
require_once '../includes/connection.inc.php';
include '../includes/header.inc.php';

if (!isset($_GET['id'])) {
    die('ID de usuario no especificado');
}

$userId = $_GET['id'];

// Obtener detalles del usuario
$stmt = $pdo->prepare("SELECT user, email FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    die('Usuario no encontrado');
}

// Contar seguidores
$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM follows WHERE user_followed = ?");
$stmt->execute([$userId]);
$followersCount = $stmt->fetchColumn();

// Obtener publicaciones del usuario
$stmt = $pdo->prepare("SELECT id, text, date FROM entries WHERE user_id = ? ORDER BY date DESC");
$stmt->execute([$userId]);
$entries = $stmt->fetchAll();
?>

<h1>Perfil de <?= htmlspecialchars($user['user']) ?></h1>
<p>Email: <?= htmlspecialchars($user['email']) ?></p>
<p>Seguidores: <?= $followersCount ?></p>

<?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] !== $userId): ?>
    <a href="../scripts/follow.php?follow_id=<?= $userId ?>">Seguir/Dejar de seguir</a>
<?php endif; ?>

<h2>Publicaciones</h2>
<?php foreach ($entries as $entry): ?>
    <div>
        <h3><a href="entry.php?id=<?= $entry['id'] ?>"><?= htmlspecialchars(substr($entry['text'], 0, 50)) ?></a></h3>
        <p>Publicado el <?= $entry['date'] ?></p>

        <?php
        // Obtener cantidad de "me gusta" y "no me gusta" para cada publicación
        $stmtLikes = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE entry_id = ?");
        $stmtLikes->execute([$entry['id']]);
        $likesCount = $stmtLikes->fetchColumn();

        $stmtDislikes = $pdo->prepare("SELECT COUNT(*) FROM dislikes WHERE entry_id = ?");
        $stmtDislikes->execute([$entry['id']]);
        $dislikesCount = $stmtDislikes->fetchColumn();
        ?>

        <p>Me gusta: <?= $likesCount ?> | No me gusta: <?= $dislikesCount ?></p>
    </div>
<?php endforeach; ?>

<?php include '../includes/footer.inc.php'; ?>
