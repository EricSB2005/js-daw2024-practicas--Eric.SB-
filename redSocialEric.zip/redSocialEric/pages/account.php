<?php
session_start();
require_once '../includes/connection.inc.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$userId = $_SESSION['user_id'];
$error = '';
$success = '';

// Obtener los datos actuales del usuario
$stmt = $pdo->prepare("SELECT user, email FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    die('Usuario no encontrado.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username =  htmlspecialchars($user['user']);
    $email =  htmlspecialchars($user['email']);
    $password = $_POST['password'];

    // Actualizar los datos
    if (!empty($username) && !empty($email)) {
        $query = "UPDATE users SET user = ?, email = ?";
        $params = [$username, $email];

        // Actualizar la contraseña si se proporciona
        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
            $query .= ", password = ?";
            $params[] = $hashedPassword;
        }

        $query .= " WHERE id = ?";
        $params[] = $userId;

        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $success = 'Datos actualizados correctamente.';
    } else {
        $error = 'El nombre de usuario y el correo no pueden estar vacíos.';
    }
}
?>

<?php include '../includes/header.inc.php'; ?>

<h1>Mi Cuenta</h1>

<p><a href="list.php">Lista de publicaciones</a></p>
<p><a href="cancel.php">cancel</a></p>
<br>

<?php if ($error): ?>
    <p style="color: red;"><?= $error ?></p>
<?php elseif ($success): ?>
    <p style="color: green;"><?= $success ?></p>
<?php endif; ?>

<form method="post">
    <label>Usuario <strong><?= htmlspecialchars($user['user']) ?></strong></label> <br> 
    <label>Correo electrónico <strong><?= htmlspecialchars($user['email']) ?></strong></label> <br> <br>
    <label>Nueva contraseña (opcional)</label>
    <input type="password" name="password">
    <button type="submit">Guardar cambios</button>
</form>

<?php include '../includes/footer.inc.php'; ?>
