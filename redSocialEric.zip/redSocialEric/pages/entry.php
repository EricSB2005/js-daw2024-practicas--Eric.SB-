<?php
require_once '../includes/connection.inc.php';
include '../includes/header.inc.php';

if (!isset($_GET['id'])) {
    die('ID de publicación no especificado');
}

$entryId = $_GET['id'];

// Obtener detalles de la publicación
$stmt = $pdo->prepare("
    SELECT entries.text, entries.date, users.user 
    FROM entries 
    JOIN users ON entries.user_id = users.id 
    WHERE entries.id = ?
");
$stmt->execute([$entryId]);
$entry = $stmt->fetch();

if (!$entry) {
    die('Publicación no encontrada');
}

// Manejar la acción de "Me gusta" o "No me gusta"
if (isset($_GET['action']) && isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $action = $_GET['action'];

    if ($action === 'like') {
        // Verificar si ya se ha dado "me gusta"
        $stmt = $pdo->prepare("SELECT * FROM likes WHERE entry_id = ? AND user_id = ?");
        $stmt->execute([$entryId, $userId]);
        if ($stmt->rowCount() == 0) {
            // Insertar "me gusta" si no se ha dado
            $stmt = $pdo->prepare("INSERT INTO likes (entry_id, user_id) VALUES (?, ?)");
            $stmt->execute([$entryId, $userId]);
        }
    } elseif ($action === 'dislike') {
        // Verificar si ya se ha dado "no me gusta"
        $stmt = $pdo->prepare("SELECT * FROM dislikes WHERE entry_id = ? AND user_id = ?");
        $stmt->execute([$entryId, $userId]);
        if ($stmt->rowCount() == 0) {
            // Insertar "no me gusta" si no se ha dado
            $stmt = $pdo->prepare("INSERT INTO dislikes (entry_id, user_id) VALUES (?, ?)");
            $stmt->execute([$entryId, $userId]);
        }
    }
}

// Obtener comentarios de la publicación
$stmt = $pdo->prepare("
    SELECT comments.text, comments.date, users.user 
    FROM comments 
    JOIN users ON comments.user_id = users.id 
    WHERE comments.entry_id = ? 
    ORDER BY comments.date ASC
");
$stmt->execute([$entryId]);
$comments = $stmt->fetchAll();

// Obtener cantidad de "me gusta" y "no me gusta"
$stmt = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE entry_id = ?");
$stmt->execute([$entryId]);
$likesCount = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM dislikes WHERE entry_id = ?");
$stmt->execute([$entryId]);
$dislikesCount = $stmt->fetchColumn();
?>

<h1>Publicación</h1>
<article>
    <h2><?= htmlspecialchars($entry['text']) ?></h2>
    <p>Por <?= htmlspecialchars($entry['user']) ?> el <?= $entry['date'] ?></p>
    
    <!-- Enlaces para dar "Me gusta" o "No me gusta" -->
    <?php if (isset($_SESSION['user_id'])): ?>
        <p>
            <a href="?id=<?= $entryId ?>&action=like">Me gusta</a> (<?= $likesCount ?>) | 
            <a href="?id=<?= $entryId ?>&action=dislike">No me gusta</a> (<?= $dislikesCount ?>)
        </p>
    <?php endif; ?>
</article>

<h2>Comentarios</h2>
<?php foreach ($comments as $comment): ?>
    <div>
        <p><strong><?= htmlspecialchars($comment['user']) ?>:</strong> <?= htmlspecialchars($comment['text']) ?></p>
        <p><small><?= $comment['date'] ?></small></p>
    </div>
<?php endforeach; ?>

<?php if (isset($_SESSION['user_id'])): ?>
    <h3>Agregar comentario</h3>
    <form action="comment.php" method="post">
        <textarea name="text" placeholder="Escribe un comentario..." required></textarea>
        <input type="hidden" name="entry_id" value="<?= $entryId ?>">
        <button type="submit">Comentar</button>
    </form>
<?php else: ?>
    <p>Inicia sesión para comentar.</p>
<?php endif; ?>

<?php include '../includes/footer.inc.php'; ?>
