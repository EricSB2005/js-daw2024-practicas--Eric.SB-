<?php
session_start();
require_once '../includes/connection.inc.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Obtener publicaciones del usuario
$stmt = $pdo->prepare("SELECT id, text, date FROM entries WHERE user_id = ? ORDER BY date DESC");
$stmt->execute([$userId]);
$entries = $stmt->fetchAll();
?>

<?php include '../includes/header.inc.php'; ?>

<h1>Mis Publicaciones</h1>

<?php if ($entries): ?>
    <ul>
        <?php foreach ($entries as $entry): ?>
            <li>
                <p><?= htmlspecialchars(substr($entry['text'], 0, 50)) ?>...</p>
                <p><small>Publicado el <?= $entry['date'] ?></small></p>
                <a href="../pages/delete.php?id=<?= $entry['id'] ?>">Eliminar</a>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>No tienes publicaciones.</p>
<?php endif; ?>

<?php include '../includes/footer.inc.php'; ?>
