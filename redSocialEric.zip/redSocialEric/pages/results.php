<?php
session_start();
require_once '../includes/connection.inc.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$searchQuery = '';
$results = [];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['query'])) {
    $searchQuery = $_GET['query'];

    // Consultar usuarios que coincidan con la búsqueda
    $stmt = $pdo->prepare("SELECT id, user FROM users WHERE user LIKE ?");
    $stmt->execute(['%' . $searchQuery . '%']);
    $results = $stmt->fetchAll();
}

// Obtener los usuarios que el usuario actual sigue
$stmt = $pdo->prepare("SELECT user_followed FROM follows WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$followedUsers = $stmt->fetchAll(PDO::FETCH_COLUMN);
$followedUsers = array_flip($followedUsers); // Para comprobar fácilmente si un usuario está seguido
?>

<?php include '../includes/header.inc.php'; ?>

<h1>Resultados de Búsqueda</h1>

<?php if ($results): ?>
    <ul>
        <?php foreach ($results as $result): ?>
            <li>
                <a href="user.php?id=<?= $result['id'] ?>">
                    <?= htmlspecialchars($result['user']) ?>
                </a>
                <?php if ($_SESSION['user_id'] !== $result['id']): ?>
                    <form action="../scripts/follow.php" method="post" style="display: inline;">
                        <input type="hidden" name="follow_id" value="<?= $result['id'] ?>">
                        <button type="submit">
                            <?= isset($followedUsers[$result['id']]) ? 'Dejar de seguir' : 'Seguir' ?>
                        </button>
                    </form>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php elseif ($searchQuery): ?>
    <p>No se encontraron usuarios con el término "<?= htmlspecialchars($searchQuery) ?>".</p>
<?php endif; ?>

<?php include '../includes/footer.inc.php'; ?>