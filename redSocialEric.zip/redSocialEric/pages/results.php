<?php
session_start();
require_once '../includes/connection.inc.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$searchQuery = '';
$results = [];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['query'])) {
    $searchQuery = $_GET['query'];

    // Consultar usuarios que coincidan con la búsqueda
    $stmt = $pdo->prepare("SELECT id, user FROM users WHERE user LIKE ?");
    $stmt->execute(['%' . $searchQuery . '%']);
    $results = $stmt->fetchAll();
}
?>

<?php include '../includes/header.inc.php'; ?>

<h1>Resultados de Búsqueda</h1>

<?php if ($results): ?>
    <ul>
        <?php foreach ($results as $result): ?>
            <li><a href="user.php?id=<?= $result['id'] ?>"><?= htmlspecialchars($result['user']) ?></a></li>
        <?php endforeach; ?>
    </ul>
<?php elseif ($searchQuery): ?>
    <p>No se encontraron usuarios con el término "<?= htmlspecialchars($searchQuery) ?>".</p>
<?php endif; ?>

<?php include '../includes/footer.inc.php'; ?>
