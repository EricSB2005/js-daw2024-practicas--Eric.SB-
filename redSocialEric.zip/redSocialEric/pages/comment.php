<?php
session_start();
require_once '../includes/connection.inc.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $text = $_POST['text'];
    $entryId = $_POST['entry_id'];
    $userId = $_SESSION['user_id'];

    if (empty($text)) {
        $_SESSION['error'] = 'El comentario no puede estar vacío.';
        header("Location: ../pages/entry.php?id=$entryId");
        exit;
    }

    // Guardar el comentario
    $stmt = $pdo->prepare("INSERT INTO comments (entry_id, user_id, text) VALUES (?, ?, ?)");
    $stmt->execute([$entryId, $userId, $text]);

    header("Location: ../pages/entry.php?id=$entryId");
    exit;
} else {
    die('Acceso no autorizado');
}
?>

