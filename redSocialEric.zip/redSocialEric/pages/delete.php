<?php
session_start();
require_once '../includes/connection.inc.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header('Location: ../index.php');
    exit;
}

$userId = $_SESSION['user_id'];
$entryId = $_GET['id'];

// Verificar que la publicación pertenece al usuario
$stmt = $pdo->prepare("SELECT * FROM entries WHERE id = ? AND user_id = ?");
$stmt->execute([$entryId, $userId]);
$entry = $stmt->fetch();

if (!$entry) {
    die('Publicación no encontrada o acceso no autorizado.');
}

// Eliminar comentarios asociados
$stmt = $pdo->prepare("DELETE FROM comments WHERE entry_id = ?");
$stmt->execute([$entryId]);

// Eliminar la publicación
$stmt = $pdo->prepare("DELETE FROM entries WHERE id = ?");
$stmt->execute([$entryId]);

header('Location: list.php');
exit;
?>
