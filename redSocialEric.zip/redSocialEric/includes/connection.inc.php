<?php
$dsn= 'mysql:host=localhost;dbname=social';
$user = 'social'; //usuario
$pass = 'laicos'; //contraseña
$charset = 'utf8mb4';

$options = [PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"];

try {
    $pdo = new PDO($dsn,$user,$pass,$options); //conexión
    //echo'correcto';
} catch (PDOException $ex) {
    echo('Error en la conexión: ' . $ex->getMessage());
}
?>
