
<?php 
if(!isset($_SESSION)){session_start();};  // Inicia sesión si no está activa
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ULTRA RED</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<header>
    <div class="cabecera">
        <h1><a href="../index.php">ULTRA RED </a></h1>
        <img src="../img/icono.png" alt="Icono" style="width: 50px; height: 50px; border-radius: 80%; border: 2px solid #ccc;">
    </div>


    <?php if (isset($_SESSION['user_id'])): ?>  <!-- Opciones para usuarios autenticados -->
        <form action="../pages/results.php" method="get">
            <input type="text" name="query" placeholder="Buscar usuarios">
            <button type="submit">Buscar</button>
        </form>
        <a href="../pages/new.php">Nueva publicación</a>
        <a href="../pages/account.php">Mi cuenta</a>
        <a href="../pages/close.php">Cerrar sesión</a>
    <?php else: ?>
        <a href="../pages/login.php">Iniciar sesión</a>
    <?php endif; ?>
</header>
<main>
