
</main>
<footer>
    <br>
    <hr>
    <p>© 2024-25 <a href="../pages/author.php">Eric Saavedra Bort</a></p>
</footer>
</body>
</html>
