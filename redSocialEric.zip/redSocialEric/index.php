<?php
require_once 'includes/connection.inc.php';
include 'includes/header.inc.php';

// Verificar si el formulario de registro fue enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos del formulario
    $user = $_POST['user'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validar los campos (esto es un ejemplo básico, puedes agregar más validaciones)
    if (empty($user) || empty($email) || empty($password)) {
        $error = "Todos los campos son obligatorios.";
    } else {
        // Verificar si el nombre de usuario ya existe
        $stmt = $pdo->prepare("SELECT id FROM users WHERE user = ?");
        $stmt->execute([$user]);
        if ($stmt->fetch()) {
            $error = "El nombre de usuario ya está en uso. Por favor, elige otro.";
        } else {
            // Insertar el nuevo usuario en la base de datos
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);  // Encriptar la contraseña
            $stmt = $pdo->prepare("INSERT INTO users (user, email, password) VALUES (?, ?, ?)");
            if ($stmt->execute([$user, $email, $hashedPassword])) {
                $success = "¡Registro exitoso! Ahora puedes iniciar sesión.";
            } else {
                $error = "Hubo un problema al registrar el usuario. Intenta nuevamente.";
            }
        }
    }
}

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $stmt = $pdo->prepare("
        SELECT entries.id, entries.text, entries.date, users.user, users.id as user_id 
        FROM entries
        JOIN follows ON follows.user_followed = entries.user_id
        JOIN users ON entries.user_id = users.id
        WHERE follows.user_id = ?
        ORDER BY entries.date DESC
    ");
    $stmt->execute([$userId]);
    $posts = $stmt->fetchAll();
} else {
    $posts = [];
}
?>

<?php if (isset($_SESSION['user_id'])): ?>
    <h2>Tu tablón</h2>
    <?php foreach ($posts as $post): ?>
        <article>
            <h3><a href="/pages/entry.php?id=<?= $post['id'] ?>"><?= htmlspecialchars($post['text']) ?></a></h3>
            <p>Por <a href="/pages/user.php?id=<?= $post['user_id'] ?>"><?= htmlspecialchars($post['user']) ?></a> el <?= $post['date'] ?></p>
        </article>
    <?php endforeach; ?>
<?php else: ?>
    <h2>Bienvenido a ULTRA RED</h2>
    <p>Regístrate para comenzar:</p>

    <!-- Mostrar mensaje de éxito o error -->
    <?php if (isset($success)): ?>
        <p style="color: green;"><?= $success ?></p>
    <?php elseif (isset($error)): ?>
        <p style="color: red;"><?= $error ?></p>
    <?php endif; ?>

    <!-- Formulario de registro -->
    <form action="index.php" method="post">
        <input type="text" name="user" placeholder="Usuario" required>
        <input type="email" name="email" placeholder="Correo electrónico" required>
        <input type="password" name="password" placeholder="Contraseña" required>
        <button type="submit">Registrarse</button>
    </form>
<?php endif; ?>

<?php include 'includes/footer.inc.php'; ?>
